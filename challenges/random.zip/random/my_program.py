# This is a super secret flag encryptor I've created. It uses a One Time Pad(https://en.wikipedia.org/wiki/One-time_pad) , which everyone knows is super secure. Good luck!
import random
ALPHABET = "abcdefghijklmnopqrstuvwxyz0123456789_"
otp_pad = []
flag_format = "flag{"

#reads unencrypted flag from flag.txt
with open("flag.txt") as flag_file:
	flag = "".join(flag_file.readline().split(flag_format))[:-2] #Gets rid of new line character

#Tests RNG so I know its REALLY random!
with open("test.txt", "w") as test:
	for i in range(624):
		test.write(str(random.getrandbits(32)))
		test.write("\n")

#Creates the One Time Pad from pure randomness. There is no way to predict what this one time pad is!
for i in range(len(flag)):
	otp_pad.append(random.randrange(1,len(ALPHABET)))

#Encrypts the flag using the OTP
with open("enc_flag.txt", "w") as enc_flag:
	enc_flag.write(flag_format)
	i=0
	for char in flag:
		try:
			char_num = ALPHABET.index(char)
		except:
			print("{} not found in alphabet".format(char))
			continue
		char_num += otp_pad[i]
		i+=1
		enc_char = ALPHABET[char_num % len(ALPHABET)]
		enc_flag.write(enc_char)
	enc_flag.write("}")
